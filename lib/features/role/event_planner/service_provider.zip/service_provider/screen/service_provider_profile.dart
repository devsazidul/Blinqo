import 'package:blinqo/core/common/styles/global_text_style.dart';
import 'package:blinqo/core/utils/constants/icon_path.dart';
import 'package:blinqo/features/profile/controller/pick_color_controller.dart';
import 'package:blinqo/features/profile/controller/profile_controller.dart';
import 'package:blinqo/features/profile/widget/f_custom_button.dart';
import 'package:blinqo/features/role/event_planner/service_provider/controller/review_controller.dart';
import 'package:blinqo/features/role/event_planner/service_provider/widget/profile_cover_image_and_avater.dart';
import 'package:blinqo/features/role/event_planner/service_provider/widget/profile_summary_section.dart';
import 'package:blinqo/features/role/event_planner/service_provider/widget/review_tab_view_widget.dart';
import 'package:blinqo/features/role/event_planner/service_provider/widget/works_reviews_tab_bar_section.dart';
import 'package:blinqo/features/role/event_planner/service_provider/widget/works_tab_view_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ServiceProviderProfile extends StatelessWidget {
  static const String name = '/event-planner/service-provider-profile';

  const ServiceProviderProfile({super.key});

  @override
  Widget build(BuildContext context) {
    final EpSpReviewController controller = Get.put(EpSpReviewController());
    final ProfileController profileController = Get.find<ProfileController>();
    final PickColorController pickColorController =
        Get.find<PickColorController>();

    return Scaffold(
      body: Obx(() {
        return ColoredBox(
          color:
              profileController.isDarkMode.value
                  ? Color(0xff151515)
                  : Color(0xffF4F4F4),
          child: DefaultTabController(
            length: 2,
            child: NestedScrollView(
              reverse: false,
              headerSliverBuilder: (
                BuildContext context,
                bool innerBoxIsScrolled,
              ) {
                return [
                  SliverToBoxAdapter(
                    child: Column(
                      children: [
                        // Profile Cover and Avatar
                        EpSpProfileCoverImageAndAvatar(),
                        SizedBox(height: 12),

                        /// Profile summary section
                        EpSpProfileSummarySection(
                          isDarkMode: profileController.isDarkMode.value,
                        ),

                        /// massage and hire button
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 45.0),
                          child: Row(
                            spacing: 8,
                            children: [
                              Expanded(
                                child: FCustomButton(
                                  backgroundColor:
                                      profileController.isDarkMode.value ==
                                              false
                                          ? Color(0xffDCE1E6)
                                          : Color(0xff282518),
                                  child: Obx(() {
                                    return Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      spacing: 10,
                                      children: [
                                        Image.asset(
                                          IconPath.messageicon,
                                          width: 20,
                                          height: 18,
                                          color:
                                              profileController
                                                          .isDarkMode
                                                          .value ==
                                                      false
                                                  ? pickColorController
                                                      .selectedColor
                                                  : Color(0xffD4AF37),
                                        ),
                                        Text(
                                          "Message",
                                          style: getTextStyle(
                                            color:
                                                profileController
                                                            .isDarkMode
                                                            .value ==
                                                        false
                                                    ? pickColorController
                                                        .selectedColor
                                                    : Color(0xffD4AF37),
                                          ),
                                        ),
                                      ],
                                    );
                                  }),
                                ),
                              ),
                              Expanded(
                                child: FCustomButton(
                                  backgroundColor:
                                      profileController.isDarkMode.value ==
                                              false
                                          ? pickColorController.selectedColor
                                          : Color(0xffD4AF37),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    spacing: 10,
                                    children: [
                                      Image.asset(
                                        IconPath.handshake,
                                        width: 20,
                                        height: 18,
                                        color: Color(0xffffffff),
                                      ),
                                      Text("Hire"),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 40),

                        /// TabBar
                        EpSpWorksReviewsTabBarSection(),
                      ],
                    ),
                  ),
                ];
              },

              /// Tabbar view
              body: Padding(
                padding: EdgeInsets.zero,
                child: TabBarView(
                  physics: NeverScrollableScrollPhysics(),
                  children: [
                    /// Works Tab
                    EpSpWorksTabViewWidget(),

                    /// Reviews Tab
                    EpSpReviewsTabViewWidget(controller: controller),
                  ],
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}
